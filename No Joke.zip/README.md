# No Joke — A Totally Serious Esoteric Programming Language 😐

> This is a joke esolang that pretends to be serious.

## Syntax example:

SET X TO 5
SET Y TO 10
TRUST ME ADD X AND Y
NO JOKE PRINT RESULT
LAUGH IF X EQUALS Y


## How to run

python no_joke.py program.nojoke